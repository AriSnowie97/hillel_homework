#include "TemperatureController.h"

TemperatureController::TemperatureController(QObject *parent) : QObject(parent) {}

QString TemperatureController::updateFromCelsius(const QString &input) {
    bool ok;
    double val = input.toDouble(&ok);
    if (!ok || val < -273.15) {
        emit inputError();
        return "";
    }
    m_model.setCelsius(val);
    emit temperaturesUpdated(
        QString::number(m_model.celsius(), 'f', 2),
        QString::number(m_model.fahrenheit(), 'f', 2),
        QString::number(m_model.kelvin(), 'f', 2)
    );
    return "";
}

QString TemperatureController::updateFromFahrenheit(const QString &input) {
    bool ok;
    double val = input.toDouble(&ok);
    if (!ok || ((val - 32) * 5/9 + 273.15) < 0) {
        emit inputError();
        return "";
    }
    m_model.setFahrenheit(val);
    emit temperaturesUpdated(
        QString::number(m_model.celsius(), 'f', 2),
        QString::number(m_model.fahrenheit(), 'f', 2),
        QString::number(m_model.kelvin(), 'f', 2)
    );
    return "";
}

QString TemperatureController::updateFromKelvin(const QString &input) {
    bool ok;
    double val = input.toDouble(&ok);
    if (!ok || val < 0) {
        emit inputError();
        return "";
    }
    m_model.setKelvin(val);
    emit temperaturesUpdated(
        QString::number(m_model.celsius(), 'f', 2),
        QString::number(m_model.fahrenheit(), 'f', 2),
        QString::number(m_model.kelvin(), 'f', 2)
    );
    return "";
}