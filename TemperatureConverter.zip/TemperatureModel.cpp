#include "TemperatureModel.h"

TemperatureModel::TemperatureModel(QObject *parent) : QObject(parent), m_kelvin(273.15) {}

double TemperatureModel::kelvin() const {
    return m_kelvin;
}

double TemperatureModel::celsius() const {
    return m_kelvin - 273.15;
}

double TemperatureModel::fahrenheit() const {
    return (m_kelvin - 273.15) * 9/5 + 32;
}

void TemperatureModel::setKelvin(double value) {
    if (value >= 0) m_kelvin = value;
}

void TemperatureModel::setCelsius(double value) {
    double k = value + 273.15;
    if (k >= 0) m_kelvin = k;
}

void TemperatureModel::setFahrenheit(double value) {
    double k = (value - 32) * 5/9 + 273.15;
    if (k >= 0) m_kelvin = k;
}