#ifndef TEMPERATURECONTROLLER_H
#define TEMPERATURECONTROLLER_H

#include <QObject>
#include "TemperatureModel.h"

class TemperatureController : public QObject
{
    Q_OBJECT

private:
    TemperatureModel m_model;

public:
    explicit TemperatureController(QObject *parent = nullptr);

    Q_INVOKABLE QString updateFromCelsius(const QString &input);
    Q_INVOKABLE QString updateFromFahrenheit(const QString &input);
    Q_INVOKABLE QString updateFromKelvin(const QString &input);

signals:
    void temperaturesUpdated(QString celsius, QString fahrenheit, QString kelvin);
    void inputError();
};

#endif // TEMPERATURECONTROLLER_H