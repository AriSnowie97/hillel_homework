#ifndef TEMPERATUREMODEL_H
#define TEMPERATUREMODEL_H

#include <QObject>

class TemperatureModel : public QObject
{
    Q_OBJECT

private:
    double m_kelvin;

public:
    explicit TemperatureModel(QObject *parent = nullptr);

    double kelvin() const;
    double celsius() const;
    double fahrenheit() const;

    void setKelvin(double value);
    void setCelsius(double value);
    void setFahrenheit(double value);
};

#endif // TEMPERATUREMODEL_H